<footer class="site-footer container">
  <p>&copy; <?php echo date('Y'); ?> Revolt Strategies</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>