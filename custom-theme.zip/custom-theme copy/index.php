<?php get_header(); ?>

<main class="site-main">
  <p>This is the fallback index.php. If you're seeing this, front-page.php isn't active.</p>
</main>

<?php get_footer(); ?>